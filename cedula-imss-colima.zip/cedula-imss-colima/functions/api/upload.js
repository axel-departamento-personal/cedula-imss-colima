// functions/api/upload.js
export async function onRequestPost(context) {
  const { request, env } = context;
  const data = await request.json();
  let con=0, sin=0;
  const stmt = env.DB.prepare(`
    INSERT INTO validacion_suplentes 
    (matricula,nombre,fecha_asistencia,unidad,tiene_contrato,contrato_que_ampara,procede_pago)
    VALUES (?,?,?,?,?,?,?)`
  );
  for(const r of data){
    const tiene = r.tiene_contrato?1:0;
    if(tiene) con++; else sin++;
    await stmt.bind(
      String(r.matricula||''), 
      r.nombre||'', 
      r.fecha_asistencia||'', 
      r.unidad||'', 
      tiene, 
      r.contrato_que_ampara||'', 
      r.procede_pago||''
    ).run();
  }
  return new Response(JSON.stringify({
    ok:true, total:data.length, con_contrato:con, sin_contrato:sin
  }), {headers:{"Content-Type":"application/json"}});
}