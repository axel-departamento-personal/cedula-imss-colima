-- schema.sql - Opcion B Cloudflare D1
CREATE TABLE IF NOT EXISTS validacion_suplentes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  matricula TEXT NOT NULL,
  nombre TEXT,
  fecha_asistencia DATE,
  hora TEXT,
  unidad TEXT,
  fec_ini1 DATE, fec_fin1 DATE,
  fec_ini2 DATE, fec_fin2 DATE,
  fec_ini3 DATE, fec_fin3 DATE,
  fec_ini4 DATE, fec_fin4 DATE,
  fec_ini5 DATE, fec_fin5 DATE,
  fec_ini6 DATE, fec_fin6 DATE,
  fec_ini7 DATE, fec_fin7 DATE,
  fec_ini8 DATE, fec_fin8 DATE,
  fec_ini9 DATE, fec_fin9 DATE,
  tiene_contrato BOOLEAN,
  contrato_que_ampara TEXT,
  procede_pago TEXT,
  fecha_carga TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  quincena TEXT
);

CREATE INDEX idx_matricula ON validacion_suplentes(matricula);
CREATE INDEX idx_procede ON validacion_suplentes(procede_pago);

CREATE VIEW vista_si_proceden AS 
SELECT * FROM validacion_suplentes WHERE tiene_contrato=1;

CREATE VIEW vista_no_proceden AS 
SELECT * FROM validacion_suplentes WHERE tiene_contrato=0;